#!/usr/bin/perl

require "setup_journal.pl";
require "displayFile.pl";
require "setCookies.pl";
require "draw_header.pl";
require "draw_navigation.pl";
require "print_comment_form.pl";
require "concatenate_comment.pl";
require "mail_comment_to_rob.pl";
require "save_comment_to_file.pl";
require "comment_logger.pl";

use CGI qw(:all);
use CGI::Cookie;

$query = new CGI;

$| = 1;        # if set to nonzero, forces a flush after every write or print

$debug = $query->param('debug');
$action = $query->param('action');
$date = $query->param('date');

if($file = $query->param('file'))
{
    $filename = "$journal_base/$file";
}

# this if block is being added here because we want it to run before writing anything and we don't want to fuck with that which already exists below.
#
if ($action eq "look for comment") {
    $oh_yeah = '';  # used for debugging cookies
    $rememberme = $query->param('rememberme');
    if ($rememberme eq "on") {
	$oh_yeah = "setting cookies";
	if ($name_param = $query->param('name')) {
	    $cookie{'name'} = $name_param;
	}
	if ($email = $query->param('email')) {
	    $cookie{'email'} = $email;
	}
    } else {
	$cookie{'name'} = "deleted";
	$cookie{'email'} = "deleted";
    }
    &setCookies;
}

print "Content-type: text/html\n\n";

&draw_header;

$debug && print $query->dump();

print "<table border=1 width='100%'><tr><td>";
&draw_navigation("journal");
print "</td></tr></table>\n";

if ($action eq "look for comment") {
    if ($query->param('comment') || $query->param('quicklist')) {

	&concatenate_comment("mail");  # parameter tells what fields to extract and how
	&mail_comment_to_rob;
	
	&concatenate_comment("file");  # parameter tells what fields to extract and how
	&save_comment_to_file;

	&comment_logger;

	if ($query->param('quicklist') eq "Where can I send you money?") {
	    print"<br><form action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\">\n";
	    print"<input type=\"hidden\" name=\"cmd\" value=\"_xclick\">\n";
	    print"<input type=\"hidden\" name=\"business\" value=\"rob\@robnugen.com\">\n";
	    print"<input type=\"hidden\" name=\"item_name\" value=\"Rob's adventure around the US\">\n";
	    print"<input type=\"hidden\" name=\"no_shipping\" value=\"1\">\n";
	    print"<input type=\"hidden\" name=\"return\" value=\"http://www.robnugen.com/thanks/\">\n";
	    print"<input type=\"hidden\" name=\"cancel_return\" value=\"http://www.robnugen.com/journal/\">\n";
	    print"<input type=\"hidden\" name=\"cn\" value=\"Give your address for a postcard!\">\n";
	    print"<input type=\"image\" src=\"/images/x-click-but21.gif\" border=\"0\" name=\"submit\" alt=\"Make payments with PayPal - it's fast, free and secure!\">\n";
	    print"</form>\n";
	}

	print "Thank you for your comment.\n";
	print "<br>It has been saved.\n";
	print "<br><a href=\"/cgi-bin/journal.pl?date=$date\">Go back</a>.";

    }
    else {
	print "<tr><td><p>No comment given.\n";
	print "<br>Click [back] on your browser to try again, or\n";
	print "<a href=\"/cgi-bin/journal.pl?date=$date\">cancel</a>.";
    }
}

if ($action eq "") {
    print "<tr><td><p>Leave comment below.\n";
    print "<br>Comments will not usually be visible to the public, but I might publish interesting/funny ones.\n";

    &print_comment_form($file);  # we only send the file name and not the path so our structure won't be disclosed

    displayFile ($filename);

    print "</td></tr></table>";
}
    